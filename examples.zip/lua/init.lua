print("examples.zip:lua/init.lua")
require("examples/require")

