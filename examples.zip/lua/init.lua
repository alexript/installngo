require("examples/require")

