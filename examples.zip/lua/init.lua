print("examples.zip:lua/init.lua")
require("examples-zip/require")

