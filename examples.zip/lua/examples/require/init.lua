print("Hello from bundled required module!")
