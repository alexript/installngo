print("examples.zip:lua/examples/init.lua")
require("examples-zip/require")

